//import "./App.css"
import Dashboard from "./components/Dashboard";
import 'boxicons/css/boxicons.min.css';


const App = () => {
  return (
    <div>
          <Dashboard/>
    </div>
  )

}

export default App
