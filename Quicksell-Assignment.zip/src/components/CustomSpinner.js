import React from 'react';
import "../styles/spinner.css"
const CustomSpinner = () => {
  return (
    <div className="spinner-backdrop">
      <div className="spinner"></div>
    </div>
  );
}

export default CustomSpinner;